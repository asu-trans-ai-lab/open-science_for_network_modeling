from signal4gmns import *


def data_processing():
    # Step 0 Preprocessing
    set_reference_cycle_length()
    set_default_volume()
    # Step 1: load movement data and volume
    load_movement_data_and_volume()
    # Step 2: Determine major approach for each signal node and output log files
    determine_major_approach()
    # Step 3: Select left_turn treatment for each signal node and output log files
    select_left_turn_treatment()
    # Step 4: Estimate signal timing for each signal node
    estimate_signal_timing(input_preset_phase_mvmt_file=False)
    # Step 5: Output signal_timing_phase.csv and signal_timing_phase.csv Files
    output_signal_phasing_files()
    # Step 6: Output timing.csv
    output_signal_timing_file_and_modify_microLink_file()

def osm_2_gmns():
    import osm2gmns as og
    net = og.getNetFromFile('subarea_3.osm.pbf', default_lanes=True, POIs=True)
    # og.connectPOIWithNet(net)
    # og.generateNodeActivityInfo(net)
    og.consolidateComplexIntersections(net)
    og.outputNetToCSV(net, output_folder='consolidated')
    og.generateMovements(net)
    og.outputNetToCSV(net)
    og.show(net)


#    og.saveFig(net)


if __name__ == '__main__':
    #convert .osm file to movement.csv etc.
    # osm_2_gmns()


    data_processing()


